501B rank renderer recovery checkpoint
2026-10-01

Target: /mnt/data/501B_HIRES_CARD_GLYPHS.ELF
Function: draw_card_rank_text_hi.constprop.0 @ 0x12CB14
Target size: 0x248 (146 EE instructions)

Breakthrough source-shape:
- Keep sr0/sr declarations syntactically INSIDE the c loop, even though GCC hoists the row calculation.
- sr = (rotated & 1) ? (23 - sr0) : sr0
- sc0/sc remain inside c loop.
- Do not precompute gi*34.

Fresh PS2DEV clean-build result:
- candidate function address: 0x12CB14
- candidate size: 0x248 / 146 instructions
- literal instruction words matching target: 143/146
- the only three differing instruction words are rodata addresses:
  0x12CB78 target lwc1 $f24,28216(v1), candidate 24504(v1)
  0x12CBD0 target card_font base +24224, candidate +22560
  0x12CC60 target fallback row +24226, candidate +22562
- all opcode/control-flow/register-allocation instructions otherwise match literally.

Target rodata symbols:
 pip_layouts 0x195A40
 card_font16x24 0x195EA0
 suit64_club 0x196160
 suit64_diamond 0x196360
 suit64_heart 0x196560
 suit64_spade 0x196760

Candidate currently has wrong rodata ordering/addresses inherited from Fix9 source. Next step: reapply recovered exact rodata declaration/order/cardback state while preserving this newly recovered function source shape.
